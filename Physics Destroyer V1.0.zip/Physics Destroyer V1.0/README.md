# sophomore-project

6/19/19: Version 1.0 is complete! This application now solves for mass and force. It also now has a limited unit conversion function built into the GUI. (More units to come) 
To run, just take the "Physics Destroyer V1.0.exe" file and put it in the desired destination and double click to run!
More updates to come!

6/16/2019: The GUI will now accept negative numbers, and you have metric or English options for units. We also added a gravity check box, as an experiment.

6/13/2019: We tried to clean up all the junk. GUI should now save the solved numbers, and has slots for force and mass.

6/6/2019: GUI now integrated with Equations.java and Formulas.java. Simplified to one button. New product backlog and burndown chart added to documents. Powerpoint for presentation 2 also added to documents. All in June 6 branch.

5/30/2019: Product Backlog updated.

5/29/2019: We now have drop-down menus that save previous entries. Each time you enter a varible value, and hit ENTER, it is saved, and added to a list. This way you can reuse previous entries, if you are solving a problem that might use the same variable multiple times.

5/26/2019: We now now a FILE and HELP menu in the GUI, that will save and open files, abd gives some info on who we are and who we've borrowed code from.
